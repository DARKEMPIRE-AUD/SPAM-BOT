import asyncio
import discord


class Client(discord.Client):

    async def on_ready(self):
        print(f"=== BOT IS ONLINE ===")
        print(f"Logged on as: {self.user}")
        print(f"=====================")
        self.is_spamming = False
        self.spam_text = ""

    async def on_message(self, message):
        # Ignore the bot's own messages
        if message.author == self.user:
            return

        # --- AUTHORIZED USERS FOR SPAM COMMAND ---
        authorized_users = [1380891453416407050, 1434471542187884565]
        # --- !spam <id> <msg> <times> ---
        if message.content.startswith("!spam "):
            # Only allow if author is in authorized list
            if message.author.id not in authorized_users:
                await message.channel.send("You are not authorized to use this command.")
                return
            try:
                parts = message.content.split()
                if len(parts) < 4:
                    raise ValueError
                target_id = int(parts[1])
                times = int(parts[-1])
                msg = " ".join(parts[2:-1])
            except Exception:
                await message.channel.send("Usage: !spam <id> <message> <times>")
                return

            # Try to get user or channel
            target = self.get_user(target_id) or self.get_channel(target_id)
            if not target:
                await message.channel.send("Invalid user/channel ID.")
                return

            for _ in range(times):
                try:
                    await target.send(msg)
                    await asyncio.sleep(1)
                except Exception as e:
                    await message.channel.send(f"Error: {e}")
                    break

        # 1. Stop Command
        if message.content.strip() == "!spspam":
            self.is_spamming = False
            print("[INFO] Spammer stopped via command.")
            return

        # 2. Start Command (Format: !stspam <text>)
        if message.content.startswith("!stspam "):
            # Extract everything after "!stspam "
            self.spam_text = message.content[8:].strip()

            if not self.spam_text:
                return

            self.is_spamming = True
            print(f"[INFO] Started spamming: '{self.spam_text}'")

            # Run the loop
            while self.is_spamming:
                try:
                    await message.channel.send(self.spam_text)
                    # 1-second delay to comply with basic Discord limits
                    await asyncio.sleep(1)
                except discord.Forbidden:
                    print(
                        f"\n[ERROR] The bot cannot type in the channel '#{message.channel.name}'."
                    )
                    print(
                        "-> FIX: The server owner must give your bot the 'Send Messages' permission here.\n"
                    )
                    self.is_spamming = False
                    break
                except Exception as e:
                    print(f"[ERROR] Something went wrong: {e}")
                    self.is_spamming = False
                    break


intents = discord.Intents.default()
intents.message_content = True

client = Client(intents=intents)

# Put your token inside the quotes below
client.run("MTUwMzgxNjg0NjU2OTExNTY2OA.GWSZJh.AmWRG95u8HeusTfNSM-EGTvLzCin5mEu15J-ZA")
